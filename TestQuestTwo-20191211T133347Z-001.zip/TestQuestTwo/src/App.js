import React from "react";

import "bootstrap/dist/css/bootstrap.min.css";
import "./sass/styles.scss";
import Main from "./Main";

const App = () => (

  <div>
    <Main/>

  </div>

);
export default App;
